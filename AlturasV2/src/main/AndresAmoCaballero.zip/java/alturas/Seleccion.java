package alturas;

/**
 * @author Andrés Amo Caballero
 * @version 1.0
 */

public interface Seleccion {
    boolean test(Pais pais);
}
