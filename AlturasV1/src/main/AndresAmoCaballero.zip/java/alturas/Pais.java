package alturas;

/**
 * @author Andrés Amo Caballero
 * @version 1.0
 */

public record Pais(String nombre, String continente, double altura) {
}
