package genetico;

/**
 * @author Andrés Amo Caballero
 * @version 1.0
 */

public interface Problema {
    int evalua(Cromosoma c);
}
